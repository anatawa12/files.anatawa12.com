cwd=`dirname "${0}"`
java -jar ${cwd}/lib/IndyObfuscation.jar "$@"