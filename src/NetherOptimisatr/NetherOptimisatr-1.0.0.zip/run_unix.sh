cwd=`dirname "${0}"`
java -jar ${cwd}/lib/NetherOptimisatr.jar