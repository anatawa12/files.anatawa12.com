short-nethergate-jar 0.0.3
今回の配布物の使い方
windowsの場合
	run_winまたはrun_win.batをダブルクリックしてください
mac
unix
linuxの場合
	run_unixまたはrun_unix.shをダブルクリックまたはコマンドラインで"bash ./run_unix.sh"を実行してください